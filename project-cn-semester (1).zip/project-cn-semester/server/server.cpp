// server.cpp
// Compile example: g++ server/server.cpp -Icommon -std=c++17 -pthread -o server_app

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "protocol.hpp"

using namespace std::chrono_literals;
using namespace CNProj;

// ------------------------------- Logger ------------------------------------
class Logger {
    std::mutex mu;
    std::ofstream fout;
public:
    Logger(const std::string &path="server.log") {
        fout.open(path, std::ios::app);
    }
    void log(const std::string &level, const std::string &msg) {
        std::lock_guard<std::mutex> l(mu);
        std::string line = "[" + now_iso() + "] " + level + ": " + msg;
        std::cout << line << std::endl;
        if (fout.is_open()) fout << line << std::endl;
    }
} logger;

// --------------------------- Client Info -----------------------------------
struct ClientInfo {
    int tcp_fd;
    sockaddr_in addr;
    std::string campus;
    std::string dept;
    std::chrono::steady_clock::time_point last_seen;
    std::mutex send_mu;

    // Constructor - used when inserting into map
    ClientInfo(int fd,
               const sockaddr_in& a,
               const std::string& c,
               const std::string& d,
               std::chrono::steady_clock::time_point t)
        : tcp_fd(fd), addr(a), campus(c), dept(d), last_seen(t) {}

    // Disable copy and assignment (mutex is non-copyable)
    ClientInfo(const ClientInfo&) = delete;
    ClientInfo& operator=(const ClientInfo&) = delete;

    // Allow move constructor (we don't move mutex)
    ClientInfo(ClientInfo&& other) noexcept
        : tcp_fd(other.tcp_fd),
          addr(other.addr),
          campus(std::move(other.campus)),
          dept(std::move(other.dept)),
          last_seen(other.last_seen) {}
    // Delete move-assignment
    ClientInfo& operator=(ClientInfo&&) = delete;
};

// Global client map and its mutex
std::unordered_map<std::string, ClientInfo> client_map;
std::mutex client_map_mu;

// Shutdown flag
std::atomic<bool> shutdown_flag(false);

// --------------------------- Helpers ---------------------------------------
ssize_t safe_send(int fd, const std::string &msg) {
    const char *buf = msg.c_str();
    size_t total = 0;
    size_t len = msg.size();
    while (total < len) {
        ssize_t n = send(fd, buf + total, len - total, 0);
        if (n <= 0) return n;
        total += n;
    }
    return total;
}

std::vector<std::string> split_kv(const std::string &s, char sep='|') {
    std::vector<std::string> out;
    size_t start=0;
    for (size_t i=0;i<=s.size();++i) {
        if (i==s.size() || s[i]==sep) {
            out.push_back(s.substr(start, i-start));
            start = i+1;
        }
    }
    return out;
}

std::string trim(const std::string &s) {
    size_t i=0,j=s.size();
    while (i<j && isspace((unsigned char)s[i])) ++i;
    while (j>i && isspace((unsigned char)s[j-1])) --j;
    return s.substr(i,j-i);
}

std::string extract_field(const std::string &token, const std::string &prefix) {
    if (token.rfind(prefix, 0) == 0) {
        return token.substr(prefix.size());
    }
    return "";
}

// ------------------------- Map management ----------------------------------
void register_client_tcp(int tcp_fd, const std::string &campus, const std::string &dept, const sockaddr_in &addr) {
    std::string key = make_key(campus, dept);
    std::lock_guard<std::mutex> lk(client_map_mu);
    // Emplace a new ClientInfo (construct in-place)
    client_map.emplace(key, ClientInfo{
        tcp_fd,
        addr,
        campus,
        dept,
        std::chrono::steady_clock::now()
    });
    logger.log("INFO", "Registered TCP client " + key + " fd=" + std::to_string(tcp_fd));
}

void unregister_client_tcp_by_fd(int fd) {
    std::lock_guard<std::mutex> lk(client_map_mu);
    for (auto it = client_map.begin(); it != client_map.end(); ++it) {
        if (it->second.tcp_fd == fd) {
            logger.log("INFO", "Unregistering client " + it->first + " (fd=" + std::to_string(fd) + ")");
            close(it->second.tcp_fd);
            client_map.erase(it);
            return;
        }
    }
}

void update_last_seen(const std::string &campus, const std::string &dept) {
    std::string key = make_key(campus, dept);
    std::lock_guard<std::mutex> lk(client_map_mu);
    auto it = client_map.find(key);
    if (it != client_map.end()) {
        it->second.last_seen = std::chrono::steady_clock::now();
    } else {
        // Not registered via TCP; create an entry with tcp_fd = -1
        client_map.emplace(key, ClientInfo{
            -1,
            sockaddr_in{},
            campus,
            dept,
            std::chrono::steady_clock::now()
        });
        logger.log("INFO", "Heartbeat created entry for " + key);
    }
}

std::string last_seen_str(const ClientInfo &ci) {
    using namespace std::chrono;
    auto now = steady_clock::now();
    auto dur = duration_cast<std::chrono::milliseconds>(now - ci.last_seen).count();
    std::ostringstream ss;
    ss << dur << "ms ago";
    return ss.str();
}

// ------------------------- UDP Heartbeat Listener --------------------------
void udp_heartbeat_listener() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        logger.log("ERROR", "Failed to create UDP heartbeat socket");
        return;
    }
    sockaddr_in srvaddr{};
    srvaddr.sin_family = AF_INET;
    srvaddr.sin_addr.s_addr = INADDR_ANY;
    srvaddr.sin_port = htons(UDP_HB_PORT);

    if (bind(sock, (sockaddr*)&srvaddr, sizeof(srvaddr)) < 0) {
        logger.log("ERROR", "Failed to bind UDP heartbeat socket");
        close(sock);
        return;
    }
    logger.log("INFO", "UDP heartbeat listener started on port " + std::to_string(UDP_HB_PORT));

    while (!shutdown_flag.load()) {
        char buf[1024];
        sockaddr_in cliaddr{};
        socklen_t cli_len = sizeof(cliaddr);
        ssize_t n = recvfrom(sock, buf, sizeof(buf)-1, 0, (sockaddr*)&cliaddr, &cli_len);
        if (n <= 0) {
            if (shutdown_flag.load()) break;
            continue;
        }
        buf[n] = '\0';
        std::string msg(buf);
        auto tokens = split_kv(msg, '|');
        if (tokens.size() >= 3 && tokens[0] == "HEARTBEAT") {
            std::string campus = "";
            std::string dept = "";
            for (size_t i=1;i<tokens.size();++i) {
                auto &tk = tokens[i];
                if (tk.rfind("Campus:",0)==0) campus = extract_field(tk,"Campus:");
                if (tk.rfind("Dept:",0)==0) dept = extract_field(tk,"Dept:");
            }
            if (!campus.empty() && !dept.empty()) {
                update_last_seen(campus, dept);
                logger.log("INFO", "Heartbeat from " + make_key(campus,dept));
            } else {
                logger.log("WARN", "Malformed heartbeat: " + msg);
            }
        } else {
            logger.log("WARN", "Unknown UDP message: " + msg);
        }
    }

    close(sock);
    logger.log("INFO", "UDP heartbeat listener stopped");
}

// ------------------------- Cleaner Thread ---------------------------------
void cleaner_thread() {
    using namespace std::chrono;
    while (!shutdown_flag.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(CLEANER_INTERVAL_MS));
        auto now = steady_clock::now();
        std::vector<std::string> to_remove;
        {
            std::lock_guard<std::mutex> lk(client_map_mu);
            for (auto &p : client_map) {
                auto dur = duration_cast<milliseconds>(now - p.second.last_seen).count();
                if (dur > HEARTBEAT_TIMEOUT_MS) {
                    to_remove.push_back(p.first);
                }
            }
            for (auto &k : to_remove) {
                logger.log("INFO", "Pruning stale client " + k);
                auto it = client_map.find(k);
                if (it != client_map.end()) {
                    if (it->second.tcp_fd >= 0) close(it->second.tcp_fd);
                    client_map.erase(it);
                }
            }
        }
    }
}

// ------------------------- Admin Status Query ------------------------------
std::string dump_status_snapshot() {
    std::ostringstream ss;
    ss << "STATUS_SNAPSHOT\n";
    std::lock_guard<std::mutex> lk(client_map_mu);
    for (auto &p : client_map) {
        std::string k = p.first;
        auto &ci = p.second;
        ss << k << "|fd:" << ci.tcp_fd << "|last_seen:" << last_seen_str(ci) << "\n";
    }
    ss << "END_STATUS\n";
    return ss.str();
}

// ------------------------- Client Handler ---------------------------------
void client_handler_thread(int client_fd, sockaddr_in client_addr) {
    logger.log("INFO", "Client handler started for fd=" + std::to_string(client_fd));
    char buf[4096];
    std::string campus = "";
    std::string dept = "";
    bool authenticated = false;
    std::string readbuf;

    while (!shutdown_flag.load()) {
        ssize_t n = recv(client_fd, buf, sizeof(buf)-1, 0);
        if (n == 0) {
            logger.log("INFO", "Client fd=" + std::to_string(client_fd) + " closed connection");
            break;
        } else if (n < 0) {
            logger.log("ERROR", "Recv error on fd=" + std::to_string(client_fd) + " errno=" + std::to_string(errno));
            break;
        }
        buf[n] = '\0';
        readbuf.append(buf, n);
        size_t pos;
        while ((pos = readbuf.find('\n')) != std::string::npos) {
            std::string line = readbuf.substr(0,pos);
            readbuf.erase(0,pos+1);
            line = trim(line);
            if (line.empty()) continue;

            // AUTH flow
            if (!authenticated) {
                auto toks = split_kv(line,'|');
                if (toks.size()>=1 && toks[0]=="AUTH") {
                    for (size_t i=1;i<toks.size();++i) {
                        if (toks[i].rfind("Campus:",0)==0) campus = extract_field(toks[i],"Campus:");
                        if (toks[i].rfind("Dept:",0)==0) dept = extract_field(toks[i],"Dept:");
                    }
                    if (!campus.empty() && !dept.empty()) {
                        authenticated = true;
                        register_client_tcp(client_fd,campus,dept,client_addr);
                        safe_send(client_fd, "AUTH_OK\n");
                    } else {
                        safe_send(client_fd, "ERROR|AuthMalformed\n");
                        logger.log("WARN", "Malformed auth from fd=" + std::to_string(client_fd) + " : " + line);
                    }
                    continue;
                }
            }

            // Admin status query
            if (line == "QUERY|STATUS") {
                auto snapshot = dump_status_snapshot();
                safe_send(client_fd, snapshot + "\n");
                continue;
            }

            // Message routing
            auto toks = split_kv(line,'|');
            if (toks.size()>=1 && toks[0]=="MSG") {
                std::string fromC="", fromD="", toC="", toD="", body="";
                for (size_t i=1;i<toks.size();++i) {
                    if (toks[i].rfind("FromCampus:",0)==0) fromC = extract_field(toks[i],"FromCampus:");
                    if (toks[i].rfind("FromDept:",0)==0) fromD = extract_field(toks[i],"FromDept:");
                    if (toks[i].rfind("ToCampus:",0)==0) toC = extract_field(toks[i],"ToCampus:");
                    if (toks[i].rfind("ToDept:",0)==0) toD = extract_field(toks[i],"ToDept:");
                    if (toks[i].rfind("Body:",0)==0) body = extract_field(toks[i],"Body:");
                }
                if (toC.empty() || toD.empty() || body.empty()) {
                    safe_send(client_fd, "ERROR|MalformedMessage\n");
                    continue;
                }
                std::string target_key = make_key(toC,toD);
                // find destination
                {
                    std::lock_guard<std::mutex> lk(client_map_mu);
                    auto it = client_map.find(target_key);
                    if (it == client_map.end() || it->second.tcp_fd < 0) {
                        safe_send(client_fd, "ERROR|DestinationNotFound\n");
                        logger.log("INFO", "Message routing failed: " + target_key + " not found");
                        continue;
                    }
                    int destfd = it->second.tcp_fd;
                    std::ostringstream out;
                    out << "FORWARD|FromCampus:" << (fromC.empty() ? campus : fromC)
                        << "|FromDept:" << (fromD.empty() ? dept : fromD)
                        << "|Body:" << body << "\n";
                    // send under dest's send mutex
                    {
                        std::lock_guard<std::mutex> sendlk(it->second.send_mu);
                        ssize_t sent = safe_send(destfd, out.str());
                        if (sent <= 0) {
                            safe_send(client_fd, "ERROR|SendFailed\n");
                            logger.log("WARN", "Failed to forward to " + target_key + " fd=" + std::to_string(destfd));
                        } else {
                            safe_send(client_fd, "DELIVERED\n");
                            logger.log("INFO", "Routed message " + make_key((fromC.empty()?campus:fromC),(fromD.empty()?dept:fromD)) + " -> " + target_key);
                            it->second.last_seen = std::chrono::steady_clock::now();
                            // Update sender last_seen as well
                            update_last_seen(campus, dept);
                        }
                    }
                }
                continue;
            }

            if (line.rfind("DISCONNECT",0) == 0) {
                logger.log("INFO", "Client requested DISCONNECT: fd=" + std::to_string(client_fd));
                unregister_client_tcp_by_fd(client_fd);
                close(client_fd);
                return;
            }

            // Unknown command
            safe_send(client_fd, "ERROR|UnknownCommand\n");
            logger.log("WARN", "Unknown command from fd=" + std::to_string(client_fd) + " : " + line);
        }
    }

    // cleanup
    unregister_client_tcp_by_fd(client_fd);
    close(client_fd);
    logger.log("INFO", "Handler thread exiting for fd=" + std::to_string(client_fd));
}

// ------------------------- TCP Acceptor -----------------------------------
void tcp_acceptor(int listen_fd) {
    while (!shutdown_flag.load()) {
        sockaddr_in cliaddr{};
        socklen_t len = sizeof(cliaddr);
        int connfd = accept(listen_fd, (sockaddr*)&cliaddr, &len);
        if (connfd < 0) {
            if (shutdown_flag.load()) break;
            logger.log("ERROR", "Accept failed errno=" + std::to_string(errno));
            continue;
        }
        std::thread t(client_handler_thread, connfd, cliaddr);
        t.detach();
    }
}

// ------------------------- Main --------------------------------------------
int main() {
    logger.log("INFO", "Server starting up");

    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        logger.log("ERROR", "Failed to create TCP socket");
        return 1;
    }
    int opt = 1;
    setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    sockaddr_in servaddr{};
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(TCP_PORT);
    if (bind(listen_fd, (sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        logger.log("ERROR", "Bind failed for TCP port " + std::to_string(TCP_PORT));
        close(listen_fd);
        return 1;
    }
    if (listen(listen_fd, 128) < 0) {
        logger.log("ERROR", "Listen failed");
        close(listen_fd);
        return 1;
    }
    logger.log("INFO", "TCP listening on port " + std::to_string(TCP_PORT));

    // Start UDP heartbeat listener thread
    std::thread udp_thread(udp_heartbeat_listener);
    udp_thread.detach();

    // Start cleaner thread
    std::thread clean_thread(cleaner_thread);
    clean_thread.detach();

    // Start acceptor (runs in main thread)
    tcp_acceptor(listen_fd);

    // Shutdown
    shutdown_flag.store(true);
    close(listen_fd);
    logger.log("INFO", "Server shutting down");
    return 0;
}

