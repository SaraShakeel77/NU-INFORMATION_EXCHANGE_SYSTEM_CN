// protocol.hpp
#pragma once
#include <string>
#include <chrono>

namespace CNProj {
    // Default network ports
    constexpr int TCP_PORT = 9000;
    constexpr int UDP_HB_PORT = 9001;
    constexpr int UDP_BCAST_PORT = 9002;

    // Timing (ms)
    constexpr int HEARTBEAT_INTERVAL_MS = 3000;
    constexpr int HEARTBEAT_TIMEOUT_MS = 12000;
    constexpr int CLEANER_INTERVAL_MS = 5000;

    // Admin token (change for production)
    const std::string ADMIN_TOKEN = "admintoken-CHANGE_ME";

    // Utility: compose key for map
    inline std::string make_key(const std::string &campus, const std::string &dept) {
        return campus + "|" + dept;
    }

    // ISO-like timestamp for logs (human readable)
    inline std::string now_iso() {
        using namespace std::chrono;
        auto t = system_clock::now();
        auto tt = system_clock::to_time_t(t);
        char buf[64];
        ctime_r(&tt, buf);
        std::string s(buf);
        if (!s.empty() && s.back() == '\n') s.pop_back();
        return s;
    }
}

