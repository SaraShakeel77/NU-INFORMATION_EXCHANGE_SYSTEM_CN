/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QFrame *frameSidebar;
    QVBoxLayout *verticalLayout_sidebar;
    QLabel *labelTitle;
    QLabel *labelCampus;
    QLineEdit *editCampus;
    QLabel *labelDept;
    QLineEdit *editDept;
    QLabel *labelServerIp;
    QLineEdit *editServerIp;
    QPushButton *btnConnect;
    QLabel *statusLabel;
    QSpacerItem *verticalSpacer;
    QFrame *frameMain;
    QVBoxLayout *verticalLayout_main;
    QLabel *labelTo;
    QHBoxLayout *horizontalLayout_to;
    QLineEdit *editToCampus;
    QLineEdit *editToDept;
    QPushButton *btnSend;
    QTextEdit *editMessage;
    QLabel *labelLog;
    QListWidget *logList;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(900, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        frameSidebar = new QFrame(centralwidget);
        frameSidebar->setObjectName(QStringLiteral("frameSidebar"));
        frameSidebar->setFrameShape(QFrame::StyledPanel);
        verticalLayout_sidebar = new QVBoxLayout(frameSidebar);
        verticalLayout_sidebar->setObjectName(QStringLiteral("verticalLayout_sidebar"));
        labelTitle = new QLabel(frameSidebar);
        labelTitle->setObjectName(QStringLiteral("labelTitle"));

        verticalLayout_sidebar->addWidget(labelTitle);

        labelCampus = new QLabel(frameSidebar);
        labelCampus->setObjectName(QStringLiteral("labelCampus"));

        verticalLayout_sidebar->addWidget(labelCampus);

        editCampus = new QLineEdit(frameSidebar);
        editCampus->setObjectName(QStringLiteral("editCampus"));

        verticalLayout_sidebar->addWidget(editCampus);

        labelDept = new QLabel(frameSidebar);
        labelDept->setObjectName(QStringLiteral("labelDept"));

        verticalLayout_sidebar->addWidget(labelDept);

        editDept = new QLineEdit(frameSidebar);
        editDept->setObjectName(QStringLiteral("editDept"));

        verticalLayout_sidebar->addWidget(editDept);

        labelServerIp = new QLabel(frameSidebar);
        labelServerIp->setObjectName(QStringLiteral("labelServerIp"));

        verticalLayout_sidebar->addWidget(labelServerIp);

        editServerIp = new QLineEdit(frameSidebar);
        editServerIp->setObjectName(QStringLiteral("editServerIp"));

        verticalLayout_sidebar->addWidget(editServerIp);

        btnConnect = new QPushButton(frameSidebar);
        btnConnect->setObjectName(QStringLiteral("btnConnect"));

        verticalLayout_sidebar->addWidget(btnConnect);

        statusLabel = new QLabel(frameSidebar);
        statusLabel->setObjectName(QStringLiteral("statusLabel"));

        verticalLayout_sidebar->addWidget(statusLabel);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_sidebar->addItem(verticalSpacer);


        horizontalLayout->addWidget(frameSidebar);

        frameMain = new QFrame(centralwidget);
        frameMain->setObjectName(QStringLiteral("frameMain"));
        frameMain->setFrameShape(QFrame::StyledPanel);
        verticalLayout_main = new QVBoxLayout(frameMain);
        verticalLayout_main->setObjectName(QStringLiteral("verticalLayout_main"));
        labelTo = new QLabel(frameMain);
        labelTo->setObjectName(QStringLiteral("labelTo"));

        verticalLayout_main->addWidget(labelTo);

        horizontalLayout_to = new QHBoxLayout();
        horizontalLayout_to->setObjectName(QStringLiteral("horizontalLayout_to"));
        editToCampus = new QLineEdit(frameMain);
        editToCampus->setObjectName(QStringLiteral("editToCampus"));

        horizontalLayout_to->addWidget(editToCampus);

        editToDept = new QLineEdit(frameMain);
        editToDept->setObjectName(QStringLiteral("editToDept"));

        horizontalLayout_to->addWidget(editToDept);

        btnSend = new QPushButton(frameMain);
        btnSend->setObjectName(QStringLiteral("btnSend"));

        horizontalLayout_to->addWidget(btnSend);


        verticalLayout_main->addLayout(horizontalLayout_to);

        editMessage = new QTextEdit(frameMain);
        editMessage->setObjectName(QStringLiteral("editMessage"));

        verticalLayout_main->addWidget(editMessage);

        labelLog = new QLabel(frameMain);
        labelLog->setObjectName(QStringLiteral("labelLog"));

        verticalLayout_main->addWidget(labelLog);

        logList = new QListWidget(frameMain);
        logList->setObjectName(QStringLiteral("logList"));

        verticalLayout_main->addWidget(logList);


        horizontalLayout->addWidget(frameMain);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "NU-Info Campus Client (Qt)", Q_NULLPTR));
        frameSidebar->setObjectName(QApplication::translate("MainWindow", "Sidebar", Q_NULLPTR));
        labelTitle->setText(QApplication::translate("MainWindow", "Campus Client", Q_NULLPTR));
        labelCampus->setText(QApplication::translate("MainWindow", "Campus", Q_NULLPTR));
        labelDept->setText(QApplication::translate("MainWindow", "Dept", Q_NULLPTR));
        labelServerIp->setText(QApplication::translate("MainWindow", "Server IP", Q_NULLPTR));
        editServerIp->setText(QApplication::translate("MainWindow", "127.0.0.1", Q_NULLPTR));
        btnConnect->setText(QApplication::translate("MainWindow", "Connect", Q_NULLPTR));
        statusLabel->setText(QApplication::translate("MainWindow", "Disconnected", Q_NULLPTR));
        labelTo->setText(QApplication::translate("MainWindow", "Send To (Campus | Dept)", Q_NULLPTR));
        editToCampus->setPlaceholderText(QApplication::translate("MainWindow", "Campus e.g. Karachi", Q_NULLPTR));
        editToDept->setPlaceholderText(QApplication::translate("MainWindow", "Dept e.g. EE", Q_NULLPTR));
        btnSend->setText(QApplication::translate("MainWindow", "Send", Q_NULLPTR));
        editMessage->setPlaceholderText(QApplication::translate("MainWindow", "Type your message...", Q_NULLPTR));
        labelLog->setText(QApplication::translate("MainWindow", "Activity / Messages", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
