// client.cpp
// Compile example: g++ client/client.cpp -Icommon -std=c++17 -pthread -o client_app

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <csignal>
#include <cstring>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>

#include "protocol.hpp"

using namespace CNProj;
// trim helper (same as server)
std::string trim(const std::string &s) {
    size_t i = 0, j = s.size();
    while (i < j && isspace((unsigned char)s[i])) ++i;
    while (j > i && isspace((unsigned char)s[j - 1])) --j;
    return s.substr(i, j - i);
}


std::atomic<bool> running(true);
int tcp_fd = -1;
std::string campus_global, dept_global;

void log_info(const std::string &s) {
    std::cout << "[" << now_iso() << "] " << s << std::endl;
}

// TCP receiver thread: prints forwarded messages from server
void tcp_recv_thread() {
    char buf[4096];
    std::string readbuf;
    while (running.load()) {
        ssize_t n = recv(tcp_fd, buf, sizeof(buf)-1, 0);
        if (n == 0) {
            log_info("Server closed connection");
            running.store(false);
            break;
        } else if (n < 0) {
            log_info("Recv error, errno=" + std::to_string(errno));
            running.store(false);
            break;
        }
        buf[n] = '\0';
        readbuf.append(buf, n);
        size_t pos;
        while ((pos = readbuf.find('\n')) != std::string::npos) {
            std::string line = readbuf.substr(0,pos);
            readbuf.erase(0,pos+1);
            if (line.rfind("FORWARD|",0) == 0) {
                std::cout << "\n[INCOMING] " << line << std::endl;
                std::cout << ">> "; std::cout.flush();
            } else if (line.rfind("AUTH_OK",0) == 0) {
                log_info("Authenticated by server");
            } else if (line.rfind("DELIVERED",0) == 0) {
                log_info("Message delivered");
            } else if (line.rfind("ERROR|",0) == 0) {
                std::cout << "[SERVER ERROR] " << line << std::endl;
            } else {
                std::cout << "[SERVER] " << line << std::endl;
            }
        }
    }
}

// UDP heartbeat thread
void udp_heartbeat_thread(const std::string &server_ip) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        log_info("Failed to create UDP socket for heartbeat");
        return;
    }
    sockaddr_in servaddr{};
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(UDP_HB_PORT);
    servaddr.sin_addr.s_addr = inet_addr(server_ip.c_str());

    while (running.load()) {
        std::ostringstream out;
        out << "HEARTBEAT|Campus:" << campus_global << "|Dept:" << dept_global << "|TS:" << std::to_string(std::time(nullptr));
        std::string msg = out.str();
        sendto(sock, msg.c_str(), msg.size(), 0, (sockaddr*)&servaddr, sizeof(servaddr));
        std::this_thread::sleep_for(std::chrono::milliseconds(HEARTBEAT_INTERVAL_MS));
    }
    close(sock);
}

// UDP broadcast listener thread (admin broadcasts)
void udp_bcast_listener_thread() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        log_info("Failed to create UDP bcast listener");
        return;
    }
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(UDP_BCAST_PORT);

    if (bind(sock, (sockaddr*)&addr, sizeof(addr)) < 0) {
        log_info("Failed to bind UDP bcast port");
        close(sock);
        return;
    }

    char buf[2048];
    while (running.load()) {
        ssize_t n = recvfrom(sock, buf, sizeof(buf)-1, 0, nullptr, nullptr);
        if (n <= 0) continue;
        buf[n] = '\0';
        std::string msg(buf);
        if (msg.rfind("ADMIN_BROADCAST|",0)==0) {
            std::cout << "\n[ADMIN BROADCAST] " << msg << std::endl;
            std::cout << ">> "; std::cout.flush();
        }
    }
    close(sock);
}

void signal_handler(int) {
    running.store(false);
    if (tcp_fd >= 0) {
        std::ostringstream ss;
        ss << "DISCONNECT|Campus:" << campus_global << "|Dept:" << dept_global << "\n";
        send(tcp_fd, ss.str().c_str(), ss.str().size(), 0);
    }
}

int main(int argc, char **argv) {
    std::string server_ip = "127.0.0.1";
    if (argc >= 3) {
        campus_global = argv[1];
        dept_global = argv[2];
    } else {
        std::cout << "Usage: ./client_app <CampusName> <DeptName> [server_ip]\n";
        return 1;
    }
    if (argc >= 4) server_ip = argv[3];

    signal(SIGINT, signal_handler);
    log_info("Starting client for " + campus_global + " | " + dept_global);

    // create TCP socket and connect
    tcp_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (tcp_fd < 0) {
        log_info("Failed to create TCP socket");
        return 1;
    }
    sockaddr_in servaddr{};
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(TCP_PORT);
    servaddr.sin_addr.s_addr = inet_addr(server_ip.c_str());

    if (connect(tcp_fd, (sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        log_info("Failed to connect to server");
        close(tcp_fd);
        return 1;
    }

    // send AUTH
    {
    std::ostringstream auth;
    auth << "AUTH|Campus:" << campus_global << "|Dept:" << dept_global << "\n";
    send(tcp_fd, auth.str().c_str(), auth.str().size(), 0);
}


    std::thread t_recv(tcp_recv_thread);
    std::thread t_hb(udp_heartbeat_thread, server_ip);
    std::thread t_bcast(udp_bcast_listener_thread);

    // Main UI loop
    while (running.load()) {
        std::cout << ">> "; std::cout.flush();
        std::string line;
        if (!std::getline(std::cin, line)) {
            running.store(false);
            break;
        }
        line = trim(line);
        if (line.empty()) continue;
        if (line == "/exit") {
            running.store(false);
            break;
        }
        if (line.rfind("/send ",0)==0) {
            std::istringstream iss(line);
            std::string cmd, targetC, targetD;
            iss >> cmd >> targetC >> targetD;
            std::string body;
            std::getline(iss, body);
            body = trim(body);
            if (targetC.empty() || targetD.empty() || body.empty()) {
                std::cout << "Usage: /send <TargetCampus> <TargetDept> <Message>\n";
                continue;
            }
            std::ostringstream out;
            out << "MSG|FromCampus:" << campus_global << "|FromDept:" << dept_global
                << "|ToCampus:" << targetC << "|ToDept:" << targetD
                << "|Body:" << body << "\n";
            send(tcp_fd, out.str().c_str(), out.str().size(), 0);
            continue;
        }
        if (line == "/status") {
            send(tcp_fd, std::string("QUERY|STATUS\n").c_str(), strlen("QUERY|STATUS\n"), 0);
            continue;
        }
        if (line == "/help") {
            std::cout << "Commands:\n";
            std::cout << "  /send <Campus> <Dept> <Message>\n";
            std::cout << "  /status\n  /exit\n";
            continue;
        }
        std::cout << "Unknown command. Use /help\n";
    }

    // graceful disconnect
    {
        std::ostringstream ss;
        ss << "DISCONNECT|Campus:" << campus_global << "|Dept:" << dept_global << "\n";
        send(tcp_fd, ss.str().c_str(), ss.str().size(), 0);
    }

    close(tcp_fd);
    running.store(false);
    t_recv.join();
    t_hb.join();
    t_bcast.join();
    log_info("Client exiting");
    return 0;
}

