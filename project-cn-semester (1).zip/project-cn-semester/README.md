
# NU-Information Exchange System (FAST-NUCES Multi-Campus Network)

This is a VS Code–ready C++ project implementing:

- Central TCP server (`server_app`)
- Campus clients with TCP + UDP heartbeat + UDP broadcast receive (`client_app`)
- Admin console with TCP status query + UDP broadcast (`admin_app`)

## Build (VS Code)

Use **Ctrl+Shift+B** and choose:

- `Build Server`
- `Build Client`
- `Build Admin`
- or `Build All`

## Build (Terminal)

From project root:

```bash
g++ server/server.cpp -Icommon -std=c++17 -pthread -o server_app
g++ client/client.cpp -Icommon -std=c++17 -pthread -o client_app
g++ admin/admin_console.cpp -Icommon -std=c++17 -pthread -o admin_app
```

## Run

1. Start server:

```bash
./server_app
```

2. Start some clients (each in its own terminal):

```bash
./client_app Lahore CS 127.0.0.1
./client_app Karachi EE 127.0.0.1
```

3. Start admin console:

```bash
./admin_app 127.0.0.1
```

### Client commands

Inside a client:

- `/send Karachi EE Hello` → sends message to Karachi EE
- `/status` → ask server for status snapshot
- `/exit` → disconnect

### Admin commands

In `admin_app`:

- `status` → query server for status snapshot (TCP)
- `broadcast` → send a UDP broadcast to all clients
- `exit` → quit admin console
