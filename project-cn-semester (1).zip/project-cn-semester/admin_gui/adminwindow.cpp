
#include "adminwindow.h"
#include "ui_adminwindow.h"

#include <QFile>
#include <QDateTime>
#include <QMessageBox>

AdminWindow::AdminWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::AdminWindow)
    , net(new NetworkManagerAdmin(this))
{
    ui->setupUi(this);
    loadTheme();

    ui->clientsTable->setColumnCount(3);
    ui->clientsTable->setHorizontalHeaderLabels(
        QStringList() << "Campus" << "Dept" << "Last Seen");

    connect(ui->btnConnect, &QPushButton::clicked,
            this, &AdminWindow::onConnectClicked);
    connect(ui->btnBroadcast, &QPushButton::clicked,
            this, &AdminWindow::onBroadcastClicked);

    connect(net, &NetworkManagerAdmin::heartbeatUpdated,
            this, &AdminWindow::onHeartbeatUpdated);
    connect(net, &NetworkManagerAdmin::logMessage,
            this, &AdminWindow::onLogMessage);
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::loadTheme()
{
    QFile f(":/theme.qss");
    if (f.open(QFile::ReadOnly)) {
        setStyleSheet(QString::fromUtf8(f.readAll()));
    }
}

void AdminWindow::onConnectClicked()
{
    QString ip = ui->editServerIp->text().trimmed();
    if (ip.isEmpty()) {
        QMessageBox::warning(this, "Missing IP", "Please enter server IP.");
        return;
    }
    net->connectToServer(ip);
}

void AdminWindow::onBroadcastClicked()
{
    QString body = ui->editBroadcast->toPlainText().trimmed();
    if (body.isEmpty()) return;
    net->sendBroadcast(body);
    ui->editBroadcast->clear();
}

void AdminWindow::onHeartbeatUpdated(const QString &key, const QDateTime &ts)
{
    Q_UNUSED(key);
    Q_UNUSED(ts);
    refreshClientTable();
}

void AdminWindow::refreshClientTable()
{
    auto map = net->activeClients();
    ui->clientsTable->setRowCount(map.size());
    int row = 0;
    for (auto it = map.begin(); it != map.end(); ++it, ++row) {
        const auto &info = it.value();
        ui->clientsTable->setItem(row, 0, new QTableWidgetItem(info.campus));
        ui->clientsTable->setItem(row, 1, new QTableWidgetItem(info.dept));
        ui->clientsTable->setItem(row, 2, new QTableWidgetItem(info.lastSeen.toString()));
    }
}

void AdminWindow::onLogMessage(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("hh:mm:ss");
    ui->logList->addItem("[" + ts + "] " + msg);
}
