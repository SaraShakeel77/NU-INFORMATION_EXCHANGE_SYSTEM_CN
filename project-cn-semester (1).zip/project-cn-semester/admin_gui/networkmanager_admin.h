
#ifndef NETWORKMANAGER_ADMIN_H
#define NETWORKMANAGER_ADMIN_H

#include <QObject>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QDateTime>
#include <QMap>

struct ClientEntry {
    QString campus;
    QString dept;
    QDateTime lastSeen;
};

class NetworkManagerAdmin : public QObject
{
    Q_OBJECT
public:
    explicit NetworkManagerAdmin(QObject *parent = nullptr);

    void connectToServer(const QString &ip);
    void sendBroadcast(const QString &body);

    QMap<QString, ClientEntry> activeClients() const { return clients; }

signals:
    void heartbeatUpdated(const QString &key, const QDateTime &ts);
    void logMessage(const QString &msg);

private slots:
    void onTcpReadyRead();
    void onUdpHeartbeatReady();

private:
    QTcpSocket *tcp;
    QUdpSocket *udpHeartbeat;
    QUdpSocket *udpBroadcast;

    QMap<QString, ClientEntry> clients;
};

#endif // NETWORKMANAGER_ADMIN_H
