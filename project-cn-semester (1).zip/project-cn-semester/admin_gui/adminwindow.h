
#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QMainWindow>
#include "networkmanager_admin.h"

QT_BEGIN_NAMESPACE
namespace Ui { class AdminWindow; }
QT_END_NAMESPACE

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();

private slots:
    void onConnectClicked();
    void onBroadcastClicked();
    void onHeartbeatUpdated(const QString &key, const QDateTime &ts);
    void onLogMessage(const QString &msg);

private:
    Ui::AdminWindow *ui;
    NetworkManagerAdmin *net;

    void loadTheme();
    void refreshClientTable();
};

#endif // ADMINWINDOW_H
