
#include "networkmanager_admin.h"
#include <QHostAddress>
#include <QDebug>
#include "../common/protocol.hpp"

using namespace CNProj;

NetworkManagerAdmin::NetworkManagerAdmin(QObject *parent)
    : QObject(parent)
{
    tcp = new QTcpSocket(this);
    udpHeartbeat = new QUdpSocket(this);
    udpBroadcast = new QUdpSocket(this);

    connect(tcp, &QTcpSocket::readyRead,
            this, &NetworkManagerAdmin::onTcpReadyRead);

    bool ok = udpHeartbeat->bind(QHostAddress::AnyIPv4,
                                 UDP_HB_PORT,
                                 QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        emit logMessage("Failed to bind UDP heartbeat port");
    } else {
        connect(udpHeartbeat, &QUdpSocket::readyRead,
                this, &NetworkManagerAdmin::onUdpHeartbeatReady);
    }
}

void NetworkManagerAdmin::connectToServer(const QString &ip)
{
    tcp->connectToHost(ip, TCP_PORT);
    QObject::connect(tcp, &QTcpSocket::connected, this, [this]() {
        emit logMessage("Connected to server over TCP");
        // Authenticate as Admin client (Campus:Admin, Dept:Console)
        QString auth = "AUTH|Campus:Admin|Dept:Console\n";
        tcp->write(auth.toUtf8());
        tcp->flush();
    });
}

void NetworkManagerAdmin::sendBroadcast(const QString &body)
{
    if (!udpBroadcast->isOpen()) {
        udpBroadcast->close();
    }
    bool ok = udpBroadcast->bind(QHostAddress::AnyIPv4,
                                 0,
                                 QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    Q_UNUSED(ok);
    QByteArray pkt = QString("ADMIN_BROADCAST|Body:%1\n").arg(body).toUtf8();
    udpBroadcast->writeDatagram(pkt, QHostAddress::Broadcast, UDP_BCAST_PORT);
    emit logMessage("Broadcast sent: " + body);
}

void NetworkManagerAdmin::onTcpReadyRead()
{
    QByteArray data = tcp->readAll();
    emit logMessage("Server: " + QString::fromUtf8(data));
}

void NetworkManagerAdmin::onUdpHeartbeatReady()
{
    while (udpHeartbeat->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(udpHeartbeat->pendingDatagramSize()));
        udpHeartbeat->readDatagram(datagram.data(), datagram.size());

        QString line = QString::fromUtf8(datagram).trimmed();
        // Expecting HEARTBEAT|Campus:XYZ|Dept:ABC|TS:...
        QString campus, dept;
        const auto toks = line.split('|');
        for (const auto &t : toks) {
            if (t.startsWith("Campus:"))
                campus = t.mid(QString("Campus:").size());
            else if (t.startsWith("Dept:"))
                dept = t.mid(QString("Dept:").size());
        }
        if (!campus.isEmpty() && !dept.isEmpty()) {
            QString key = campus + "|" + dept;
            ClientEntry e;
            e.campus = campus;
            e.dept = dept;
            e.lastSeen = QDateTime::currentDateTime();
            clients[key] = e;
            emit heartbeatUpdated(key, e.lastSeen);
        }
    }
}
