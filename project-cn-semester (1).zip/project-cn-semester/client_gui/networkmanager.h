
#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QTimer>

class NetworkManager : public QObject
{
    Q_OBJECT
public:
    explicit NetworkManager(QObject *parent = nullptr);

    void connectToServer(const QString &campus,
                         const QString &dept,
                         const QString &ip);
    void sendMessage(const QString &toCampus,
                     const QString &toDept,
                     const QString &body);

signals:
    void connected();
    void disconnected();
    void messageReceived(const QString &fromCampus,
                         const QString &fromDept,
                         const QString &body);
    void broadcastReceived(const QString &body);

private slots:
    void onTcpReadyRead();
    void onTcpDisconnected();
    void onBroadcastReady();
    void onHeartbeatTimeout();

private:
    QTcpSocket *tcp;
    QUdpSocket *udpBroadcast;
    QUdpSocket *udpHeartbeat;
    QTimer *heartbeatTimer;

    QString selfCampus;
    QString selfDept;
    QString serverIp;
};

#endif // NETWORKMANAGER_H
