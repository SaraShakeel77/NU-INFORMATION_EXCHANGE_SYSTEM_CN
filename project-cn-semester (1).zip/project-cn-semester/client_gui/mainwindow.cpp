
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFile>
#include <QDateTime>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , net(new NetworkManager(this))
{
    ui->setupUi(this);
    loadTheme();

    // Connect UI signals
    connect(ui->btnConnect, &QPushButton::clicked,
            this, &MainWindow::onConnectClicked);
    connect(ui->btnSend, &QPushButton::clicked,
            this, &MainWindow::onSendClicked);

    // Connect network signals
    connect(net, &NetworkManager::connected,
            this, &MainWindow::onConnected);
    connect(net, &NetworkManager::disconnected,
            this, &MainWindow::onDisconnected);
    connect(net, &NetworkManager::messageReceived,
            this, &MainWindow::onMessageReceived);
    connect(net, &NetworkManager::broadcastReceived,
            this, &MainWindow::onBroadcastReceived);

    ui->statusLabel->setText("Disconnected");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadTheme()
{
    QFile f(":/theme.qss");
    if (f.open(QFile::ReadOnly)) {
        QString qss = QString::fromUtf8(f.readAll());
        this->setStyleSheet(qss);
    }
}

void MainWindow::appendLog(const QString &text)
{
    QString ts = QDateTime::currentDateTime().toString("hh:mm:ss");
    ui->logList->addItem("[" + ts + "] " + text);
}

void MainWindow::onConnectClicked()
{
    QString campus = ui->editCampus->text().trimmed();
    QString dept   = ui->editDept->text().trimmed();
    QString ip     = ui->editServerIp->text().trimmed();

    if (campus.isEmpty() || dept.isEmpty() || ip.isEmpty()) {
        QMessageBox::warning(this, "Missing Info",
                             "Please fill Campus, Dept and Server IP.");
        return;
    }

    net->connectToServer(campus, dept, ip);
}

void MainWindow::onSendClicked()
{
    QString toCampus = ui->editToCampus->text().trimmed();
    QString toDept   = ui->editToDept->text().trimmed();
    QString body     = ui->editMessage->toPlainText().trimmed();

    if (toCampus.isEmpty() || toDept.isEmpty() || body.isEmpty()) {
        QMessageBox::warning(this, "Missing Fields",
                             "Target campus, dept and message are required.");
        return;
    }

    net->sendMessage(toCampus, toDept, body);
    appendLog("You → " + toCampus + " | " + toDept + ": " + body);
    ui->editMessage->clear();
}

void MainWindow::onBroadcastReceived(const QString &msg)
{
    appendLog("📢 ADMIN: " + msg);
}

void MainWindow::onMessageReceived(const QString &fromCampus,
                                   const QString &fromDept,
                                   const QString &body)
{
    appendLog("💬 " + fromCampus + " | " + fromDept + ": " + body);
}

void MainWindow::onConnected()
{
    ui->statusLabel->setText("Connected");
    appendLog("Connected to server.");
}

void MainWindow::onDisconnected()
{
    ui->statusLabel->setText("Disconnected");
    appendLog("Disconnected from server.");
}
