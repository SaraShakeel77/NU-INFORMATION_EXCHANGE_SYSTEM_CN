
#include "networkmanager.h"
#include <QHostAddress>
#include <QDateTime>
#include <QDebug>

#include "../common/protocol.hpp"
using namespace CNProj;

NetworkManager::NetworkManager(QObject *parent)
    : QObject(parent)
{
    tcp = new QTcpSocket(this);
    udpBroadcast = new QUdpSocket(this);
    udpHeartbeat = new QUdpSocket(this);
    heartbeatTimer = new QTimer(this);

    connect(tcp, &QTcpSocket::readyRead,
            this, &NetworkManager::onTcpReadyRead);
    connect(tcp, &QTcpSocket::disconnected,
            this, &NetworkManager::onTcpDisconnected);

    connect(udpBroadcast, &QUdpSocket::readyRead,
            this, &NetworkManager::onBroadcastReady);

    connect(heartbeatTimer, &QTimer::timeout,
            this, &NetworkManager::onHeartbeatTimeout);

    // Bind UDP broadcast listener (for admin broadcasts)
    bool ok = udpBroadcast->bind(QHostAddress::AnyIPv4,
                                 UDP_BCAST_PORT,
                                 QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        qWarning() << "Failed to bind UDP broadcast port" << UDP_BCAST_PORT;
    }
}

void NetworkManager::connectToServer(const QString &campus,
                                     const QString &dept,
                                     const QString &ip)
{
    selfCampus = campus;
    selfDept = dept;
    serverIp = ip;

    tcp->connectToHost(ip, TCP_PORT);
    connect(tcp, &QTcpSocket::connected, this, [this]() {
        // Send AUTH
        QString line = QString("AUTH|Campus:%1|Dept:%2\n")
                .arg(selfCampus, selfDept);
        tcp->write(line.toUtf8());
        tcp->flush();

        // Start heartbeat timer
        heartbeatTimer->start(HEARTBEAT_INTERVAL_MS);

        emit connected();
    });
}

void NetworkManager::sendMessage(const QString &toCampus,
                                 const QString &toDept,
                                 const QString &body)
{
    if (tcp->state() != QAbstractSocket::ConnectedState)
        return;

    QString line = QString("MSG|FromCampus:%1|FromDept:%2|ToCampus:%3|ToDept:%4|Body:%5\n")
            .arg(selfCampus, selfDept, toCampus, toDept, body);
    tcp->write(line.toUtf8());
    tcp->flush();
}

void NetworkManager::onTcpReadyRead()
{
    QByteArray data = tcp->readAll();
    static QByteArray buffer;
    buffer.append(data);

    int idx;
    while ((idx = buffer.indexOf('\n')) != -1) {
        QByteArray rawLine = buffer.left(idx);
        buffer.remove(0, idx + 1);
        QString line = QString::fromUtf8(rawLine).trimmed();
        if (line.isEmpty()) continue;

        if (line == "AUTH_OK") {
            // ignore for now
            continue;
        }

        if (line.startsWith("FORWARD|")) {
            // Parse: FORWARD|FromCampus:...|FromDept:...|Body:...
            QStringList toks = line.split('|');
            QString fromC, fromD, body;
            for (const auto &t : toks) {
                if (t.startsWith("FromCampus:"))
                    fromC = t.mid(QString("FromCampus:").size());
                else if (t.startsWith("FromDept:"))
                    fromD = t.mid(QString("FromDept:").size());
                else if (t.startsWith("Body:"))
                    body = t.mid(QString("Body:").size());
            }
            emit messageReceived(fromC, fromD, body);
            continue;
        }

        if (line.startsWith("ERROR|")) {
            qWarning() << "Server error:" << line;
            continue;
        }
    }
}

void NetworkManager::onTcpDisconnected()
{
    heartbeatTimer->stop();
    emit disconnected();
}

void NetworkManager::onBroadcastReady()
{
    while (udpBroadcast->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(udpBroadcast->pendingDatagramSize()));
        udpBroadcast->readDatagram(datagram.data(), datagram.size());
        QString line = QString::fromUtf8(datagram).trimmed();

        if (line.startsWith("ADMIN_BROADCAST")) {
            QStringList toks = line.split('|');
            QString body;
            for (const auto &t : toks) {
                if (t.startsWith("Body:"))
                    body = t.mid(QString("Body:").size());
            }
            if (!body.isEmpty())
                emit broadcastReceived(body);
        }
    }
}

void NetworkManager::onHeartbeatTimeout()
{
    // Send UDP heartbeat to server
    if (serverIp.isEmpty())
        return;

    QByteArray hb = QString("HEARTBEAT|Campus:%1|Dept:%2|TS:%3\n")
            .arg(selfCampus,
                 selfDept,
                 QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
            .toUtf8();

    udpHeartbeat->writeDatagram(hb,
                                QHostAddress(serverIp),
                                UDP_HB_PORT);
}
