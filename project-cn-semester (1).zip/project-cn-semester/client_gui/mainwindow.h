
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "networkmanager.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onConnectClicked();
    void onSendClicked();
    void onBroadcastReceived(const QString &msg);
    void onMessageReceived(const QString &fromCampus,
                           const QString &fromDept,
                           const QString &body);
    void onConnected();
    void onDisconnected();

private:
    Ui::MainWindow *ui;
    NetworkManager *net;

    void loadTheme();
    void appendLog(const QString &text);
};

#endif // MAINWINDOW_H
