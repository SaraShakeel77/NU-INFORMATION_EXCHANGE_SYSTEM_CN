/********************************************************************************
** Form generated from reading UI file 'adminwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWINDOW_H
#define UI_ADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_root;
    QFrame *frameHeader;
    QHBoxLayout *horizontalLayout_header;
    QLabel *labelTitle;
    QLineEdit *editServerIp;
    QPushButton *btnConnect;
    QHBoxLayout *horizontalLayout_body;
    QFrame *frameSidebar;
    QVBoxLayout *verticalLayout_sidebar;
    QPushButton *btnClients;
    QPushButton *btnBroadcastView;
    QPushButton *btnLogs;
    QSpacerItem *verticalSpacer;
    QFrame *frameMain;
    QVBoxLayout *verticalLayout_main;
    QLabel *labelClients;
    QTableWidget *clientsTable;
    QLabel *labelBroadcast;
    QTextEdit *editBroadcast;
    QPushButton *btnBroadcast;
    QLabel *labelLogs;
    QListWidget *logList;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AdminWindow)
    {
        if (AdminWindow->objectName().isEmpty())
            AdminWindow->setObjectName(QStringLiteral("AdminWindow"));
        AdminWindow->resize(900, 600);
        centralwidget = new QWidget(AdminWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        verticalLayout_root = new QVBoxLayout(centralwidget);
        verticalLayout_root->setObjectName(QStringLiteral("verticalLayout_root"));
        frameHeader = new QFrame(centralwidget);
        frameHeader->setObjectName(QStringLiteral("frameHeader"));
        horizontalLayout_header = new QHBoxLayout(frameHeader);
        horizontalLayout_header->setObjectName(QStringLiteral("horizontalLayout_header"));
        labelTitle = new QLabel(frameHeader);
        labelTitle->setObjectName(QStringLiteral("labelTitle"));

        horizontalLayout_header->addWidget(labelTitle);

        editServerIp = new QLineEdit(frameHeader);
        editServerIp->setObjectName(QStringLiteral("editServerIp"));

        horizontalLayout_header->addWidget(editServerIp);

        btnConnect = new QPushButton(frameHeader);
        btnConnect->setObjectName(QStringLiteral("btnConnect"));

        horizontalLayout_header->addWidget(btnConnect);


        verticalLayout_root->addWidget(frameHeader);

        horizontalLayout_body = new QHBoxLayout();
        horizontalLayout_body->setObjectName(QStringLiteral("horizontalLayout_body"));
        frameSidebar = new QFrame(centralwidget);
        frameSidebar->setObjectName(QStringLiteral("frameSidebar"));
        verticalLayout_sidebar = new QVBoxLayout(frameSidebar);
        verticalLayout_sidebar->setObjectName(QStringLiteral("verticalLayout_sidebar"));
        btnClients = new QPushButton(frameSidebar);
        btnClients->setObjectName(QStringLiteral("btnClients"));

        verticalLayout_sidebar->addWidget(btnClients);

        btnBroadcastView = new QPushButton(frameSidebar);
        btnBroadcastView->setObjectName(QStringLiteral("btnBroadcastView"));

        verticalLayout_sidebar->addWidget(btnBroadcastView);

        btnLogs = new QPushButton(frameSidebar);
        btnLogs->setObjectName(QStringLiteral("btnLogs"));

        verticalLayout_sidebar->addWidget(btnLogs);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_sidebar->addItem(verticalSpacer);


        horizontalLayout_body->addWidget(frameSidebar);

        frameMain = new QFrame(centralwidget);
        frameMain->setObjectName(QStringLiteral("frameMain"));
        verticalLayout_main = new QVBoxLayout(frameMain);
        verticalLayout_main->setObjectName(QStringLiteral("verticalLayout_main"));
        labelClients = new QLabel(frameMain);
        labelClients->setObjectName(QStringLiteral("labelClients"));

        verticalLayout_main->addWidget(labelClients);

        clientsTable = new QTableWidget(frameMain);
        clientsTable->setObjectName(QStringLiteral("clientsTable"));

        verticalLayout_main->addWidget(clientsTable);

        labelBroadcast = new QLabel(frameMain);
        labelBroadcast->setObjectName(QStringLiteral("labelBroadcast"));

        verticalLayout_main->addWidget(labelBroadcast);

        editBroadcast = new QTextEdit(frameMain);
        editBroadcast->setObjectName(QStringLiteral("editBroadcast"));

        verticalLayout_main->addWidget(editBroadcast);

        btnBroadcast = new QPushButton(frameMain);
        btnBroadcast->setObjectName(QStringLiteral("btnBroadcast"));

        verticalLayout_main->addWidget(btnBroadcast);

        labelLogs = new QLabel(frameMain);
        labelLogs->setObjectName(QStringLiteral("labelLogs"));

        verticalLayout_main->addWidget(labelLogs);

        logList = new QListWidget(frameMain);
        logList->setObjectName(QStringLiteral("logList"));

        verticalLayout_main->addWidget(logList);


        horizontalLayout_body->addWidget(frameMain);


        verticalLayout_root->addLayout(horizontalLayout_body);

        AdminWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AdminWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        AdminWindow->setStatusBar(statusbar);

        retranslateUi(AdminWindow);

        QMetaObject::connectSlotsByName(AdminWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AdminWindow)
    {
        AdminWindow->setWindowTitle(QApplication::translate("AdminWindow", "NU-Info Admin Console (Qt)", Q_NULLPTR));
        frameHeader->setObjectName(QApplication::translate("AdminWindow", "Header", Q_NULLPTR));
        labelTitle->setText(QApplication::translate("AdminWindow", "Admin Console", Q_NULLPTR));
        editServerIp->setPlaceholderText(QApplication::translate("AdminWindow", "Server IP (e.g. 127.0.0.1)", Q_NULLPTR));
        btnConnect->setText(QApplication::translate("AdminWindow", "Connect", Q_NULLPTR));
        frameSidebar->setObjectName(QApplication::translate("AdminWindow", "Sidebar", Q_NULLPTR));
        btnClients->setText(QApplication::translate("AdminWindow", "Connected Clients", Q_NULLPTR));
        btnBroadcastView->setText(QApplication::translate("AdminWindow", "Broadcast", Q_NULLPTR));
        btnLogs->setText(QApplication::translate("AdminWindow", "Logs", Q_NULLPTR));
        labelClients->setText(QApplication::translate("AdminWindow", "Active Clients", Q_NULLPTR));
        labelBroadcast->setText(QApplication::translate("AdminWindow", "Broadcast Message", Q_NULLPTR));
        btnBroadcast->setText(QApplication::translate("AdminWindow", "Send Broadcast", Q_NULLPTR));
        labelLogs->setText(QApplication::translate("AdminWindow", "Logs", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AdminWindow: public Ui_AdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWINDOW_H
